# Welcome to the Linux challenge!

This small challenge serves to check and improve your Linux knowledge.
For this purpose, there is a virtual machine with a minimal Linux system.
Within it there are different users (level1, level2,...) whose passwords have to be found.
The password for Level i+1 is hidden somewhere in Level i.
After logging in as user level$i, there is a hint in the file "~/.hint".

Who can find all the passwords first?

## Starting the VM

To start the virtual machine, you have to unpack the archive first.
Then, depending on the system:
- on Windows: double-click WindowsLevinux.vbs
- on MacOS: double-click Levinux
- on Linux: right-click on LinuxLevinux.sh and choose "Run in Terminal"

## Closing the VM

Every logged-in user can shut down the machine via 'sudo poweroff'
In the rare case it freezes, you can simply terminate the process 'qemu-system-i386'.
On Linux, this is done with the command 'killall qemu-system-i386'.

## Passwords and levels

All passwords have the format 'bs_' followed by 10 symbols.
Suppose you are logged in as the user 'level1' and found the password.
Now log out with 'exit' (or Ctrl+D) and log in with the user name 'level2' and the retrieved password.
It would make sense to write down all found passwords in a text file.

# Help

Many of the commands support the option --help, e.g.:

```
level1@box:~$ mkdir --help

BusyBox v1.24.2 (2016-05-16 13:46:43 UTC) multi-call binary.
Usage: mkdir [OPTIONS] DIRECTORY...
Create DIRECTORY

  -m MODE Mode
  -p      No error if exists; make parent directories as needed
```

Further help can also be found on the internet, if you can find the right search terms from the hints.

Should the display in your terminal get messed up (which happens e.g. when you look at a binary filer with cat) use the command 'reset'.

## Command overview

The following commands may prove useful for solving the tasks:
cat
chmod
cd
gcc
grep
less
ls
mkdir 
more
reset
sh
tar
touch

Additionally, input/output redirection and 'pipes' may help.

